import sys
sys.path.append('.')
__all__ = ['quote_query', 'quote_context']





