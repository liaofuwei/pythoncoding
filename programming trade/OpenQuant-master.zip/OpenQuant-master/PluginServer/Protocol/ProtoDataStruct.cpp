#include "stdafx.h"
#include "ProtoDataStruct.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

